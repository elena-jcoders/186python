nxenesit = ["Eda,", "Rubina"]
produktet = {
    "mosha":2,
    "mbiemri":"Krasniqi",
    "mosha":15,
    "eshteNxenese":True
}
name = eda.get("emri")
print(name)
print(eda["mosha"])
eda["eshteNxenese"] = "eshteStudente"
print(eda)

for x in eda:
    print(x)
# na i printon elementet e objektit
for i in eda.values():
    print(i)