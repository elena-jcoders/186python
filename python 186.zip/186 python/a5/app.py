# for loop - e perserit ni veprim varsisht sa i thojm na
ditet  = ["E hane", "E marte", "E merkure"]
ditet.append("E ejte")
# E hane - osht indexi 0
ditet.remove("E hane")
del ditet[1] #heket e merkurja

print(ditet)
for x in ditet:
    print(ditet[0])

tuple1 = ()
tuple2 = ("Elena", 25, 8.9, True)
# tuple eshte nje koleksion me vlera te ndryshme te tipeve te te dhenave. Jane vlera te pandryshushme edhe nuk mundemi me largu asnje vlere

# set - i hek vlerat qe jan te dyfishta

myList = [1,1,1,1,2,2,2,2,4,5,5,5]
print(set(myList))

numrat = set()
numrat.add(1)
print(numrat)
numrat.add(2)
print(numrat)

numri1 = int(input())
operatori = input()
numri2 = int(input())

if operatori == "+":
    print(numri1+numri2)
elif operatori == "-":
    print(numri1-numri2)
elif operatori == "*":
    print(numri1*numri2)
elif operatori == "/":
    print(numri1/numri2)
