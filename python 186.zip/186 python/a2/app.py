# # variabla eshte nje vlere e ruajtur psh score
# emri = "Elena"
# mosha = 25
# # Numrat psh 25 nuk shenohen me thojza sepse jan te tipit int
# # Int - integer dmth per numra
# print(emri,mosha)

# # Të shkruhet programi i cili llogarit moshën tuaj, duke u bazuar në vitin tuaj të lindjes.

# vitiLindjes = 2000
# vitiAktual = 2025
# mosha = vitiAktual - vitiLindjes
# print(mosha)
# print("Mosha ime eshte:", mosha)
# # String - ne thonjza

# # input - osht kur mundet perdoruesi me shenu mrenda ne to
# print("Sheno emrin: ")
# emri = input() 
# print("Hello " + emri)

# # Të ruhen moshat e studentëve në variabla të veçanta për secilin student të grupit, dhe përmes funksionit print() të shfaqet mesatarja e këtyre moshave.
# nx1 = 2
# nx2 = 4
# nx3 = 5
# print((nx1+nx2+nx3)/3)
# # floats - nr me pik

# # Të shkruhet programi i cili e llogarit diametrin, sipërfaqen dhe perimetri i rrethit i cili ka rrezen r=5.
# r = 5
# diametri = 2*r
# print(diametri)
# siperfaqja = 3.14 * 5*5 
# print(siperfaqja)
# perimetri = 2*3.14*5
# print(perimetri)

# && - and
# ! - not
a = 5
b = 5
if (a>b):
    print("Numri a eshte me i madh se numri b")
elif a==b:
    print("Numrat jane te njejte")
else:
    print("Nuk eshte")


    # Të krijohet programi i cili varësisht nga vlera në variablën pikët e llogarit dhe shfaq notën sipas rregullave:

# Nota 1 -> 0 - 29 pikë
# Nota 2 -> 30 - 49
# Nota 3 -> 50 - 69
# Nota 4 -> 70 - 89
# Nota 5 -> 90 - 100

piket = 87
if (piket>=0 and piket <=29):
    print("Nota 1")
elif(piket>=30 and piket <=49):
    print("Nota 2")
