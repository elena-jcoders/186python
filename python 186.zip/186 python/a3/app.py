# if - pjesa par e kushtit
# elif - pjes shtes e kushtit
# else - nese nuk plotsohet kushti

# nr1 = 5
# nr2 = 5
# if nr1>nr2:
#     print("Numri 1 eshte me i madh se numri 2")
# elif nr1==nr2:
#     print("Numrat jane te barabarte")
# else:
#     print("Numri 2 eshte me i madh se numri 1")

# Të krijohet programi i cili varësisht nga vlera në variablën pikët e llogarit dhe shfaq notën sipas rregullave:

# Nota 1 -> 0 - 29 pikë
# Nota 2 -> 30 - 49
# Nota 3 -> 50 - 69
# Nota 4 -> 70 - 89
# Nota 5 -> 90 - 100
# piket = 95
# if piket>=0 and piket <=29:
#     print("Nota eshte 1")
# elif piket>=30 and piket <=49:
#     print("Nota eshte 2")
# elif piket>=50 and piket<=69:
#     print("Nota eshte 3")
# elif piket >=70 and piket<=89:
#     print("Nota eshte 4")
# elif piket>=90 and piket<=100:
#     print("Nota 5")
# else:
#     print("Piket gabim")

# numri = 5
numri = int(input())
if numri%2 == 0:
    print("Numri eshte cift")
else:
    print("Numri eshte tek")

# === - edhe vlerat edhe tipet e te dhenave
