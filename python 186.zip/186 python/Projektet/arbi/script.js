class Account {
  #balance; 

  constructor(owner, balance) {
    this.owner = owner;
    this.#balance = balance;
  }

  deposit(amount) {
    this.#balance += amount;
    console.log(`${this.owner} depozitoi ${amount}€ Balanca: ${this.#balance}€`);
  }

  withdraw(amount) {
    if (amount > this.#balance) {
      console.log(` ${this.owner} nuk ka mjaft para`);
    } else {
      this.#balance -= amount;
      console.log(`${this.owner} terhoqi ${amount}€. Balanca: ${this.#balance}€`);
    }
  }

  getBalance() {
    return this.#balance;
  }
}

class SavingsAccount extends Account {
  constructor(owner, balance, interest) {
    super(owner, balance);
    this.interest = interest;
  }

  deposit(amount) {
    let bonus = amount * this.interest;
    let total = amount + bonus;

    console.log(` Llogari kursimi: Bonus interesi ${bonus}€`);

    super.deposit(total);
  }
}

class StudentAccount extends Account {
  withdraw(amount) {
    console.log(` Terheqje per studentin ${this.owner}`);
    super.withdraw(amount);
  }
}

let riga = new Account("Riga", 200);
let riga1 = new SavingsAccount("Riga1", 300, 0.05);
let riga2 = new StudentAccount("Riga2", 150);

riga.deposit(50);
riga1.deposit(50);
riga2.withdraw(20);

console.log(`Balanca e Riges: ${riga.getBalance()}€`);
console.log(`Balanca e Riges1: ${riga1.getBalance()}€`);
console.log(`Balanca e Riges2: ${riga2.getBalance()}€`);
