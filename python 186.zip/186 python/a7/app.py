# research funksionet - 
print("Hello")
# Funksionet na sherbejne per me kriju diqka te caktume edhe mos mu perserit kodi disa here, kur mundeni me kriju vetem nje here
# function mbledh
# def - definon qe ka mu perdor ni funksion
def my_Function():
    print("Hello Elena")
my_Function()
# myFunctionMy - camel case
# my_Function - snake case

# name = "Elena" #- variabel globale se eshte jasht funskionit
def mbledh(x,y):
    # x,y - jane parametra
    # x = 5 - variabel lokale se eshte mrenda funksionit
    print(f"Shuma e numrave x edhe y eshte:  {x+y}") 
mbledh(5,8)
# 5,8 - jane argumente, dmth kur paramentrat e marin nje vlere atehere jane argumente

def emri():
    return emri
# - funksione kthyese qe nuk duhet me printu diqka

def calculate(x,y,o):
    # o - mundet me kon ose + ose *
    if o == "+":
        print(f"Mbledhja e x edhe y eshte {x+y}")
    elif o == "*":
        print(f"Shumezimi i x edhe y eshte {x*y}")
    elif o == "/":
        print (f"Pjestimi i x edhe y eshte {x/y}")
    elif o == "%":
        print(f"Modulimi i x edhe y eshte {x%y}")
calculate(5,10,"+")
calculate(5,10,"*")
calculate(5,10,"/")
calculate(5,10,"%")