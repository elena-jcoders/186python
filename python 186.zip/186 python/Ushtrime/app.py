# Krijoni një klasë Apartment 

# Definoni një metodë __init__ për të inicializuar atributet: _id, mts2, value, dhe sold

# Krijoni një metodë sell që ndryshon sold në True dhe shfaq mesazhin nëse është shitur

# Krijoni një instancë Apartment me _id=1, mts2=100, value=5000

# Testoni metodën sell dhe verifikoni mesazhin: "Apartment {_id} was sold"

# class Apartment:
#     def __init__(self, _id, mts2, value, sold):
#         self._id = _id
#         self.mts2 = mts2
#         self.value = value
#         self.sold = False

#     def sell (self):
#         if self.sold == True:
#             print(f"Aparment with id {self._id} is sold")
#         else:
#             print(f"Aparment with id {self._id} is not sold")

# Apartment1 = Apartment("A1",2000, 60000, True )
# Apartment1.sell()
# Apartment2 = Apartment("A1",2000, 60000, False )
# Apartment2.sell()


class Apartment:
    """
    Class that represents an apartment for sale
    value is in USD
    """

    def __init__(self, _id, mts2, value):
        self._id = _id
        self.mts2 = mts2
        self.value = value
        self.sold = False

    def sell(self):
        if not self.sold:
            self.sold = True
        else:
            print("Apartment {} was sold".format(self._id))

# Krijimi i një instance të klasës Apartment
d1 = Apartment(_id=1, mts2=100, value=5000)

print("sold?", d1.sold)  # Kontrollojmë statusin e shitjes
d1.sell()  # Shesim apartamentin
print("sold?", d1.sold)  # Kontrollojmë përsëri statusin e shitjes
d1.sell()  # Provojmë të shesim përsëri apartamentin, duhet të tregojë një mesazh se është shitur

# Rezultati i pritur:
# sold? False
# sold? True
# Apartment 1 was sold