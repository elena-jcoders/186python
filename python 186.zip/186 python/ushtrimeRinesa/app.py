# variabla eshte nje vlere qe ruhet
emri = "Elena"
# String - text
# Int - numra
# Float - nr me presje dhjetore
# Complex - numra me shifra te medha
# Boolean - qe jan vlera true ose false
# List - dmth kur kemi pune me me shume se nje vlere
# Dict - objektet kur per secilen vlere mundemi me caktu edhe shume vlera te tjera mrenda
mosha = 25
cmimi = 4.5
test = 100000000000
eMartuar = False

# Operatoret Aritmetik:
# mbledhja = a+b
# zbritja = a-b
# shumzimi = a*b
# pjestim = a/b
# modulim = a%b

# Operatoret e krahasimit
# e barabarta osht ==
# e jobarabarte !=

# Operatoret logjik:
# a and b - dhe
# a or b - ose
# a not b - nuk eshte

# Janë dhënë dy numra nr1 = 10 dhe nr2 = 4, të gjendet shuma, diferenca, prodhimi, herësi dhe mbetja e tyre.

nr1 = 10
nr2 = 4
shuma = nr1+nr2 
zbritja = nr1-nr2
prodhimi = nr1*nr2
heresi = nr1/nr2
mbetja = nr1%nr2
print(shuma)

vitiLindjes = 2000
mosha = 2025 - 2000

nx1 = 25
nx2 = 23
nx3 = 20
print((nx1+nx2+nx3)/3)