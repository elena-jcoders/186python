# Detyra 1
salary = [340, 210, 450, 600, 230, 500, 550, 300]


# te gjendet shuma e pagave
shumaEpagave = 0
for paga in salary:
    shumaEpagave = shumaEpagave + paga
print(f"Shuma e pagave = {shumaEpagave}")


# paga mesatare
pagaMesatare = shumaEpagave / len(salary)
print(f"Paga mesatare = {pagaMesatare}")


pagaMin = salary[0]
pagaMax = salary[0]


for pagaAktuale in salary:
    if(pagaAktuale < pagaMin):
        pagaMin = pagaAktuale
print(f"Paga minimale = {pagaMin}")


for pagaAktuale in salary:
    if(pagaAktuale > pagaMax):
        pagaMax = pagaAktuale
print(f"Paga maximale = {pagaMax}")