# variabla eshte nje vlere e ruajtur si psh score
emri = "Elena"
mbiemri = " Muhaxheri"
mosha = 25
nxenese = False
teacher = False
emriPlote = emri + mbiemri
print(emri)
print(mbiemri)
print(mosha)
print(emriPlote)

# Tipet e te dhenave ne python:
# String - tekst
# Int - numra
# Float - numra me presje dhjetore
# Complex - qe jon numra ma te mdhaj
# Boolean - Vlera true ose false
# Lists - Kur kem shum vlera psh [Leka, Kledi, Alpi]
# Objects - psh kur dojm me rujt shum vlera per ni variabel, dojm me ja shtu emrin, mbiemrin etj

# Operatoret aritmerik:
# mbledhja = a+b 
# zbritja = a-b
# shumzim = a*b
# pjestim = a/b 
# modulimi = a%b

viti = 2022 +3
viti1 = 2022 * 3
viti2 = 2022/3

# Operatoret e krahasimit:
# a>b , a>=b
# 3>2 , 3>=2
# a<2, a<=b 
# a == b 
# a!=b - a eshte ma e ndryshme dmth sosht e njejt me b

nr1 = 10
nr2 = 4
mbledhja = nr1 + nr2
# zbritja = 
# prodhimi = 
# pjestimi = 
