# OOP - object oriented programming
# Konceptet - Abstraksioni, Polimorfizmi, Trashegimia edhe Enkapsulimi
# Abstraksioni - me mshef logjiken qe sna nevojitet
# Polimorfizmi - metoda me emer te njejte qe ne klasa te ndryshme ka pas funksionalitet te ndryshem
# Trashegimia - kur klasa femij i trashegon metodat edhe atributet e klases prind
# Enkapsulimi - kur kem perdor variabla private per mos me mujt me ju qas nje klase klasa tjeter

# Krijoni një klasë Apartment 
# Definoni një metodë __init__ për të inicializuar atributet: _id, mts2, value, dhe sold
# Krijoni një metodë sell që ndryshon sold në True dhe shfaq mesazhin nëse është shitur
# Krijoni një instancë Apartment me _id=1, mts2=100, value=5000
# Testoni metodën sell dhe verifikoni mesazhin: "Apartment {_id} was sold"
class Apartment:
    def __init__(self, _id, mts2, value,sold):
        self._id=_id
        self.mts2 = mts2
        self.value=value
        self.sold = False

    def sell(self):
        if self.sold == True:
            print(f"Apartamenti me id {self._id} eshte shitur")
        else:
            print(f"Apartamenti me id {self._id} nuk eshte shitur")

Apartamenti1 = Apartment("A1", 100, 15000, True)
Apartamenti1.sell()