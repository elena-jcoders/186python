# init - inicializon vleren fillestare
class Car:
    def __init__(self, marka, lloji, viti):
        self.marka = marka
        self.lloji = lloji
        self.viti = viti

    def displayInfo(self):
        print(f"{self.marka} {self.lloji} {self.viti}")

bmw = Car("BMW", "M4", 2025)
# eshte kriju nje objekt bmw, qe eshte nje instanc e klases Car, qe i permban vlerat per marke, lloj edhe vit
bmw.displayInfo()
        
    