nxenesit = ["Alpi", "Eda", "Orgesi", "Joni","Rinesa", "Rroni", "Eldi", "Rinesa", "Kledi"]
# Alpi - indeks 0
print(nxenesit)
nxenesit.append("Leka")
print(nxenesit)
nxenesit.remove("Orgesi")
print(nxenesit)
del nxenesit[2]
print(nxenesit)
#fshihet personi ne indeksimin e dyte


for x in nxenesit:
    print(x)