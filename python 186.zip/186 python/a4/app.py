# Loops perdoren kur deshirojme nje veprim me perserit disa here pa shkru shume reshta kod
# while loop ose e kena for loop
# for i in range (0,10):
#     print(i)

# in range - numrat qe perfshihen psh prej 0 deri te 10

for i in range (5,21):
    if i==7:
        continue
    print(i)

# continue - vazhdon edhe nuk e mer numrin te cilin e kemi caktu psh 7
for i in range(4,30):
    if i==10:
        break
    print(i)

for i in range (0,11):
    if i==3 or i==6:
        continue
    print(i)

for i in range(10,51):
    if i%2==0:
        print(i)
    if i<0:
        print("Numri eshte negativ")