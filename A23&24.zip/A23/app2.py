import matplotlib.pyplot as plt
import numpy as np

# 1,2,3,4,5
# 1.1,1.2,1.3.................10
t = np.linspace(0,10)
x = np.sin(t)
y = np.cos(t)
z = t
fig = plt.figure()
ax = fig.add_subplot(111, projection = "3d")
ax.plot(x,y,z, label = "3d Line", linewidth = 2)
# plot - pi pranon vlerat x,y,z, titulli 3d line graph, edhe madhesia e vijes ka me kon 2
# Label per x, label per y
ax.legend()
plt.show()