import matplotlib.pyplot as plt

patient_Age = [45,50,55,60,65,70,75,80]
lesion_size = [3,5,7,9,11,13,15,17]
lesion_volume = [10,15,18,22,27,30,35,38]

fig = plt.figure()
ax = fig.add_subplot(111,projection="3d")
ax.scatter(patient_Age,lesion_size,lesion_volume,c="r",marker = "o")
plt.show()

